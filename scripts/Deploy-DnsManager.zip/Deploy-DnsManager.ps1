Configuration Deploy-DnsManager
{
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    
    Node localhost
    {
        WindowsFeature InstallDNS 
        { 
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature InstallDNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]InstallDNS'
        }
    }
}